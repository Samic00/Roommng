﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RoomManagment
{
    public partial class Form3 : Form
    {
        SqlConnection cnn;
        public class Prava
        {
            public bool pr1, pr2,pr3,pr4,pr5,pr6;
        }
        string id="0";
        public void dodajID(int a)
        {
            id = a.ToString();
            textBox1.Text = id;
            SqlCommand naredba;
            SqlDataReader dataReader;
            String sql;
            sql = "select PravoID from UserPrava where UserID=" + id + " and Aktivno=1";
            cnn.Open();
            naredba = new SqlCommand(sql, cnn);
            dataReader = naredba.ExecuteReader();
            while (dataReader.Read())
            {
                if (dataReader.GetInt32(0) >= 0)
                {
                    if (dataReader.GetInt32(0) == 1)
                    {
                        checkBox1.Enabled = true;
                    }
                    if (dataReader.GetInt32(0) == 2)
                    {
                        checkBox2.Enabled = true;
                    }
                    if (dataReader.GetInt32(0) == 4)
                    {
                        checkBox4.Enabled = true;
                    }
                    if (dataReader.GetInt32(0) == 5)
                    {
                        checkBox5.Enabled = true;
                    }
                    if (dataReader.GetInt32(0) == 6)
                    {
                        checkBox6.Enabled = true;
                    }
                }
            }
            naredba.Dispose();
            cnn.Close();
        }
        public Form3()
        {
            InitializeComponent();
            string cs;
            cs = @"Data Source=192.168.43.180,51302\sqlexpress;Initial Catalog=room_management;User ID=room_mng;Password=12345";
            cnn = new SqlConnection(cs);
            checkBox1.Enabled = false;
            checkBox2.Enabled = false;
            checkBox4.Enabled = false;
            checkBox5.Enabled = false;
            checkBox6.Enabled = false;

        }
        
        public void DodajPrava(Prava p)
        {
            
            if (checkBox1.Checked == true)
            {
                p.pr1 = true;
            }
            if (checkBox2.Checked == true)
            {
                p.pr2 = true;
            }
            p.pr3 = true;
            if (checkBox4.Checked == true)
            {
                p.pr4 = true;
            }
            if (checkBox5.Checked == true)
            {
                p.pr5 = true;
            }
            if (checkBox6.Checked == true)
            {
                p.pr6 = true;
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            cnn.Open();
            Prava pra = new Prava();
            DodajPrava(pra);
            SqlCommand naredba;
            SqlDataAdapter adapter = new SqlDataAdapter();
            string sql = "";
            sql = "Insert into Users (Username, Password, FullName, Active) values('"+textBox1.Text.ToString()+"','"+CreateMD5(textBox2.Text.ToString())+"','"+textBox3.Text.ToString()+"',1); " +
                "DECLARE @id INT; set @id = SCOPE_IDENTITY();" ;
            if (pra.pr1 == true)
            {
                sql += "Insert into UserPrava (UserID,PravoID,Aktivno) values(@id,1,1); ";
            }
            if (pra.pr2 == true)
            {
                sql += "Insert into UserPrava (UserID,PravoID,Aktivno) values(@id,2,1); ";

            }
            if (pra.pr3 == true)
            {
                sql += "Insert into UserPrava (UserID,PravoID,Aktivno) values(@id,3,1); ";

            }
            if (pra.pr4 == true)
            {
                sql += "Insert into UserPrava (UserID,PravoID,Aktivno) values(@id,4,1); ";

            }
            if (pra.pr5 == true)
            {
                sql += "Insert into UserPrava (UserID,PravoID,Aktivno) values(@id,5,1); ";

            }
            if (pra.pr6 == true)
            {
                sql += "Insert into UserPrava (UserID,PravoID,Aktivno) values(@id,6,1); ";

            }
            
            naredba = new SqlCommand(sql, cnn);
            adapter.InsertCommand = new SqlCommand(sql, cnn);
            adapter.InsertCommand.ExecuteNonQuery();
            cnn.Close();
            this.Hide();
            Form1 f = Program.Form1;
            f.Show();
            Program.Form3.Close();
        }
        public static string CreateMD5(string input)
        {
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);

                return Convert.ToBase64String(hashBytes);
            }
        }
    }
}
