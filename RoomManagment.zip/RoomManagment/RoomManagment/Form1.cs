using System.Data.SqlClient;

namespace RoomManagment
{
    public partial class Form1 : Form
    {
        SqlConnection cnn; //sql connection > using System.Data.SqlClient
        public Form1()
        {
            InitializeComponent();
            string cs;
            cs = @"Data Source=192.168.43.180,51302\sqlexpress;Initial Catalog=room_management;User ID=room_mng;Password=12345";
            cnn = new SqlConnection(cs);
            SqlCommand naredba;
            SqlDataReader dataReader;
            String sql;
            sql = "select * from Rezervacije";
            cnn.Open();
            naredba = new SqlCommand(sql, cnn);
            dataReader = naredba.ExecuteReader();
            while (dataReader.Read())
            {
                listBox1.Items.Add(dataReader.GetValue(0) + "        " + dataReader.GetValue(1) + "                  " + dataReader.GetValue(2) + "                       " + dataReader.GetValue(3) + "                   " + dataReader.GetValue(4) + "                 " + dataReader.GetValue(5) + "                      " + dataReader.GetValue(6) + "                            " + dataReader.GetValue(7));
            }
            naredba.Dispose();
            cnn.Close();
        }
        public static string CreateMD5(string input)
        {
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);

                return Convert.ToBase64String(hashBytes);
            }
        }
        string id = "";
        public void dodajID(int a)
        {
            id = a.ToString();
            SqlCommand naredba;
            SqlDataReader dataReader;
            String sql;
            sql = "select PravoID from UserPrava Where UserID="+id+" and Aktivno=1";
            cnn.Open();
            naredba = new SqlCommand(sql, cnn);
            dataReader = naredba.ExecuteReader();
            while (dataReader.Read())
            {
                listBox2.Items.Add(dataReader.GetValue(0));
            }
            naredba.Dispose();
            cnn.Close();
            label9.Text = "ID Trenutno prijavljenog korisnika: "+id;
            prijaviSeToolStripMenuItem.Enabled = false;
            if (listBox2.Items.Contains(4))
            {
                registracijaToolStripMenuItem.Enabled = true;
            }
        }
        private void prijaviSeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Program.Form2.ShowDialog();
            Program.Form1.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void registracijaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 f3 = new Form3();
            f3.dodajID(int.Parse(id));
            f3.ShowDialog();
            Program.Form1.Close();

        }
    }
}