﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RoomManagment
{
    public partial class Form2 : Form
    {
        SqlConnection cnn;
        private class User
        {

        }
        public Form2()
        {
            InitializeComponent(); //sql connection > using System.Data.SqlClient
            string cs;
            cs = @"Data Source=192.168.43.180,51302\sqlexpress;Initial Catalog=room_management;User ID=room_mng;Password=12345";
            cnn = new SqlConnection(cs);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            SqlCommand naredba;
            SqlDataReader dataReader;
            String sql;
            sql = "select ID from Users where Username='"+ textBox1.Text.ToString() + "' and Password='"+CreateMD5(textBox2.Text.ToString())+"'";
            cnn.Open();
            naredba = new SqlCommand(sql, cnn);
            dataReader = naredba.ExecuteReader();
            while (dataReader.Read())
            {
                if (dataReader.GetInt32(0) >= 0)
                {
                    this.Hide();
                    Form1 reg = Program.Form1;
                    reg.dodajID(dataReader.GetInt32(0));
                    reg.ShowDialog();
                }
            }
            naredba.Dispose();
            cnn.Close();
        }
        public static string CreateMD5(string input)
        {
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);

                return Convert.ToBase64String(hashBytes);
            }
        }
    }
}
