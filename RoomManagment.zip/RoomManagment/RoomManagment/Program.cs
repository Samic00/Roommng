namespace RoomManagment
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        public static Form1 Form1 { get; private set; } // Add these two lines
        public static Form2 Form2 { get; private set; }
        public static Form3 Form3 { get; private set; }
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            Form1 = new Form1(); // Add this two lines
            Form2 = new Form2();
            Form3= new Form3();
            Application.Run(Form1);
        }
    }
}